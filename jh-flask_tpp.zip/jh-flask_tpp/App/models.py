from App.ext import db

class Letter(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255))
    citys = db.relationship('City',backref='letter',lazy=True)


class City(db.Model):
    id = db.Column(db.Integer,primary_key=True,autoincrement=True)
    regionName = db.Column(db.String(100))
    cityCode = db.Column(db.String(255))
    pinYin = db.Column(db.String(255))
    c_letter = db.Column(db.Integer,db.ForeignKey(Letter.id))

class User(db.Model):
    id = db.Column(db.Integer, autoincrement=True, primary_key=True)
    name = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(255))
    email = db.Column(db.String(50), unique=True)
    phone = db.Column(db.String(20))
    token = db.Column(db.String(255))
    permissions = db.Column(db.Integer, default=1)
    icon = db.Column(db.String(50), default='head.png')
    isactive = db.Column(db.Boolean, default=False)
    isdelete = db.Column(db.Boolean, default=False)



class Movies(db.Model):
    __tablename__ = 'movies'

    id = db.Column(db.Integer,primary_key=True)
    showname = db.Column(db.String(255))
    shownameen = db.Column(db.String(255))
    director = db.Column(db.String(255))
    leadingRole = db.Column(db.String(255))
    type = db.Column(db.String(255))
    country = db.Column(db.String(255))
    language = db.Column(db.String(255))
    duration = db.Column(db.Integer)
    screeningmodel = db.Column(db.String(255))
    openday = db.Column(db.Date)
    backgroundpicture = db.Column(db.String(255))
    flag = db.Column(db.Integer)
    isdelete = db.Column(db.Boolean,default=False)



class Cinemas(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(255))
    city = db.Column(db.String(255))
    district = db.Column(db.String(255))
    address = db.Column(db.String(255))
    phone = db.Column(db.String(255))
    score = db.Column(db.Float)
    hallnum = db.Column(db.Integer)
    servicecharge = db.Column(db.Float)
    astrict = db.Column(db.Integer)
    flag = db.Column(db.Integer)
    isdelete = db.Column(db.Boolean,default=False)












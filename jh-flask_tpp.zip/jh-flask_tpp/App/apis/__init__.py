from flask_restful import Api

from App.apis.CinemasApi import CinemasResource
from App.apis.CityApi import CityPesource
from App.apis.IconApi import IconResource
from App.apis.MoviesApi import MoviesResource
from App.apis.PasswordApi import PasswordChange
from App.apis.RegisterApi import Resister
from App.apis.UserActive import UserActive
from App.apis.loginApi import LoginApi

api = Api()
def init_api(app):
    api.init_app(app)


api.add_resource(CityPesource,'/api/v1/city/',endpoint='city')
api.add_resource(Resister,'/api/v1/resister/',endpoint='resister')
api.add_resource(UserActive,'/api/v1/useractive/',endpoint='useractive')
api.add_resource(LoginApi,'/api/v1/loginapi/',endpoint='loginapi')
api.add_resource(PasswordChange,'/api/v1/passwordchange/',endpoint='passwordchange')
api.add_resource(MoviesResource,'/api/v1/movies/',endpoint='movies')
api.add_resource(CinemasResource,'/api/v1/cinema/',endpoint='cinema')
api.add_resource(IconResource,'/api/v1/icon/',endpoint='icon')
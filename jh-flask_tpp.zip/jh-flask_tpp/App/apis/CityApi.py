from flask_restful import Resource, fields, marshal_with, marshal

from App.models import City, Letter

"""
{
    'stauts': 200,
    'msg': '获取城市列表成功',
    'data': {
        'A': [
        {
            "id":430,
            "regionName":"沧州",
            "cityCode":130900,
            "pinYin":"CANGZHOU"
        },
        {},
        {}
        ],
        'B': [{},{},{}],
        ...
    },
    'error': ''
}
"""

city_field = {
    'id':fields.Integer,
    'regionName':fields.String,
    'cityCode':fields.Integer,
    'pinYin':fields.String
}
#
# letter_field = {
#     'A':fields.List(fields.Nested(city_field))
# }
# ressult_field = {
#     'status':fields.Integer,
#     'msg':fields.String,
#     'data':fields.Nested(letter_field),
#     'error':fields.String
# }



class CityPesource(Resource):
    def post(self):
        letter = Letter.query.all()
        data = {}
        returndata = {}
        letter_fields_dynamic={}

        for item in letter:
            data[item.name] = item.citys
            letter_fields_dynamic[item.name]=fields.List(fields.Nested(city_field))


        returndata['status']=200
        returndata['msg']='城市获取成功'
        returndata['data']=data
        returndata['error']=''


        result_field_dynameic = {
            'status':fields.Integer,
            'msg':fields.String,
            'data':fields.Nested(letter_fields_dynamic),
            'error':fields.String
        }

        result = marshal(returndata,result_field_dynameic)

        return result






















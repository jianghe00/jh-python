import os

import werkzeug
from flask_restful import reqparse, fields, Resource, marshal_with
from werkzeug.utils import secure_filename

from App.ext import db
from App.models import User
from App.settings import UPLOAD_DIR

parser = reqparse.RequestParser()
parser.add_argument('token',type=str,required=True,help='请输入token')
parser.add_argument('usericon',type=werkzeug.datastructures.FileStorage, location='files', required=True, help='请选择图片')

class IconFormat(fields.Raw):
    def format(self, value):
        return '/static/img/'+value



user_field = {
    'icon':IconFormat(attribute='icon')
}

result_fields = {
    'status': fields.Integer,
    'msg': fields.String,
    'data': fields.Nested(user_field, default=''),
    'error': fields.String(default='')
}

class IconResource(Resource):
    @marshal_with(result_fields)
    def get(self):
        parse = parser.parse_args()
        token = parse.get('token')
        usericon = parse.get('usericon')
        users  = User.query.filter(User.token==token)
        if users.count():
            user=users.first()

            filename = '%d-%s'%(user.id,secure_filename(usericon.filename))
            filepath = os.path.join(UPLOAD_DIR,filename)
            usericon.save(filepath)

            user.icon = filename
            db.session.add(user)
            db.session.commit()
            returndata = {
                'status':200,
                'msg':'文件上传成功',
                'data':user
            }
            return returndata
        else:   # 找不到用户
            returndata = {
                'status': 200,
                'msg': '文件上传失败',
                'error': '用户不存在'
            }
            return returndata






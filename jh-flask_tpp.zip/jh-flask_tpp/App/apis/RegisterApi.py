import uuid

from flask_restful import reqparse, fields, Resource, marshal_with
from werkzeug.security import generate_password_hash

from App.models import User
from App.ext import db, send_email, cache

parser = reqparse.RequestParser()
parser.add_argument('name',type=str,required=True,help='请输入用户名')
parser.add_argument('password',type=str,required=True,help='输入密码')
parser.add_argument('email',type=str,required=True,help='输入邮箱')
parser.add_argument('phone',type=str,required=True,help='输入手机号')


user_field = {
    'name':fields.String,
    'token':fields.String,
    'icon':fields.String,
    'permissions':fields.Integer
}

result_field = {
    'status':fields.Integer,
    'msg':fields.String,
    'data':fields.Nested(user_field),
    'error':fields.String(default=''),
}

class Resister(Resource):
    @marshal_with(result_field)
    def post(self):
        parse = parser.parse_args()
        user = User()
        user.name = parse.get('name')
        user.password = generate_password_hash(parse.get('password'))
        user.email = parse.get('email')
        user.phone = parse.get('phone')
        user.token = str(uuid.uuid4())

        returndata = {}

        users = User.query.filter(User.name == user.name).filter(User.email == user.email)
        if users.count() > 0:  # 用户存在
            returndata['status'] = 406
            returndata['msg'] = '注册失败'
            returndata['error'] = '该用户已经注册过,直接登录即可!'
            return returndata
        else:
            users = User.query.filter(User.email == user.email)
            if users.count() > 0:  # 邮箱已经存在
                returndata['status'] = 406
                returndata['msg'] = '注册失败'
                returndata['error'] = '邮箱已存在'
                return returndata

            users = User.query.filter(User.name == user.name)
            if users.count() > 0:
                returndata['status'] = 406
                returndata['msg'] = '注册失败'
                returndata['error'] = '用户名已存在'
                return returndata

        db.session.add(user)
        db.session.commit()

        send_email(user)

        cache.set(user.token, user.id, timeout=100)


        returndata['status'] = 200
        returndata['msg'] = '注册成功'
        returndata['data'] = user

        return returndata











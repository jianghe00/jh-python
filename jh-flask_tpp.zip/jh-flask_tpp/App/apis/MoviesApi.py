from flask_restful import reqparse, fields, abort, Resource, marshal_with

from App.ext import db
from App.models import User, Movies

parser_get = reqparse.RequestParser()
parser_get.add_argument('flag',type=int)


parser_post = reqparse.RequestParser()
parser_post.add_argument('token', type=str, required=True, help='缺少token')
parser_post.add_argument('id', type=int, required=True, help='缺少id')
parser_post.add_argument('showname', type=str, required=True, help='缺少电影中文名')
parser_post.add_argument('shownameen', type=str, required=True, help='缺少英文名称')
parser_post.add_argument('director', type=str, required=True, help='缺少导演')
parser_post.add_argument('leadingRole', type=str, required=True, help='缺少主演')
parser_post.add_argument('type', type=str, required=True, help='缺少电影分类')
parser_post.add_argument('country', type=str, required=True, help='缺少产地')
parser_post.add_argument('language', type=str, required=True, help='缺少语言')
parser_post.add_argument('duration', type=int, required=True, help='缺少时长')
parser_post.add_argument('screeningmodel', type=str, required=True, help='缺少放映')
parser_post.add_argument('openday', type=str, required=True, help='缺少上映时间')
parser_post.add_argument('backgroundpicture', type=str, required=True, help='缺少图片')
parser_post.add_argument('flag', type=int, required=True, help='缺少标志位')


movie_field = {
    'id':fields.Integer,
    'showname':fields.String,
    'shownameen':fields.String,
    'director':fields.String,
    'leadingRole':fields.String,
    'type':fields.String,
    'country':fields.String,
    'language':fields.String,
    'duration':fields.Integer,
    'screeningmodel':fields.String,
    'openday':fields.String,
    'backgroundpicture':fields.String,
    'flag':fields.Integer,
}

result_field_get = {
    'status':fields.Integer,
    'msg':fields.String,
    'data':fields.List(fields.Nested(movie_field)),
    'error':fields.String,

}
result_field_post = {
'status':fields.Integer,
    'msg':fields.String,
    'data':fields.Nested(movie_field),
    'error':fields.String,

}

def check_permission_control(permission):
    def check_permission(func):
        def check(*args,**kwds):
            parse = parser_post.parse_args()
            token = parse.get('token')
            if token:
                users = User.query.filter(User.token==token)
                if users.count()>0:
                    user = users.first()
                    if user.permissions & permission == permission:
                        return  func(*args,**kwds)
                    else:
                        abort(403,message='你没有该操作权限,请联系管理员!')
                else:
                    abort(401,message='你还没有登录,请登录后操作')
            else:
                abort(401,message='你还没有登录,请登录后操作')

        return check
    return check_permission



class MoviesResource(Resource):
    @marshal_with(result_field_get)
    def get(self):
        parse = parser_get.parse_args()
        flag = parse.get('flag') or 0
        if flag:
            movies = Movies.query.filter(Movies.flag==flag)
        else:
            movies = Movies.query.all()
        returndata = {
            'status': 200,
            'msg': '获取电影列表信息成功',
            'data': movies
        }
        return returndata


    @marshal_with(result_field_post)
    @check_permission_control(2)
    def post(self):
        parse = parser_post.parse_args()

        movie = Movies()
        movie.id = parse.get('id')
        movie.showname = parse.get('showname')
        movie.shownameen = parse.get('shownameen')
        movie.director = parse.get('director')
        movie.leadingRole = parse.get('leadingRole')
        movie.type = parse.get('type')
        movie.country = parse.get('country')
        movie.language = parse.get('language')
        movie.duration = parse.get('duration')
        movie.screeningmodel = parse.get('screeningmodel')
        movie.openday = parse.get('openday')
        movie.backgroundpicture = parse.get('backgroundpicture')
        movie.flag = parse.get('flag')

        db.session.add(movie)
        db.session.commit()

        returndata = {
            'status': 200,
            'msg': '添加电影列表信息成功',
            'data': movie
        }

        return returndata

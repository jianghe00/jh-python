from flask import render_template
from flask_bootstrap import Bootstrap
from flask_caching import Cache
from flask_mail import Mail, Message
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

mail = Mail()
db = SQLAlchemy()
migrate = Migrate()
cache = Cache(config={
    'CACHE_TYPE': 'simple',
    'CACHE_KEY_PREFIX': 'flaskProject'
})
def init_ext(app):
    db.init_app(app)
    migrate.init_app(app,db)
    cache.init_app(app)
    Bootstrap(app)
    mail.init_app(app)


def send_email(user):
    msg = Message(
        subject='PTT激活邮件',
        recipients=[user.email],
        sender='13938473576@163.com'
    )
    active_url = 'http://127.0.0.1:5000/api/v1/useractive/?token=' + user.token
    body_html = render_template('useractive.html', name=user.name, active_url=active_url)
    msg.html = body_html
    mail.send(msg)


def send_mail(user):
    msg = Message(
        subject='aaaa',
        sender='13938473576@163.com',
        recipients=user.email
    )
    active = 'http://127.0.0.1:5000/api/v1/useractive/?token=' + user.token
    body_html = render_template('useractive.html', name=user.name, active_url=active)
    msg.html = body_html
    mail.send(msg)

# pip freeze >requirements.txt
# pip install -r requirements.txt


import json
import pymysql

db = pymysql.Connect(host='127.0.0.1',port=3306,user='root',database='PTT',charset='utf8',password='945050118')
cursor = db.cursor()

with open('city.json','rb') as f:
    city_collection = json.load(f)
    returnValue = city_collection.get('returnValue')
    letters = returnValue.keys()
    for letter_key in letters:
        cursor.execute("INSERT INTO letter(name) VALUES('{}')".format(letter_key))
        db.commit()

        cursor.execute("SELECT * FROM letter WHERE name='{}'".format(letter_key))
        db.commit()
        result = cursor.fetchone()
        letter_id = result[0]

        citys = returnValue[letter_key]
        for city in citys:
            cursor.execute(
                "INSERT INTO city(id,regionName,cityCode,pinYin,c_letter) VALUES({}, '{}', {}, '{}', {})".format(
                    city.get('id'), city.get('regionName'), city.get('cityCode'), city.get('pinYin'), letter_id))
            db.commit()





from flask import Flask
from App.apis import init_api
from App.ext import init_ext
from App.settings import config
from App.views import blue


def creat_app(env_name=None):
    app = Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///sql8.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
    app.config['SECRET_KEY'] = '!@#$%^&*DGHJKL%^&*(CVBERTYU1231'
    init_ext(app)
    init_api(app)
    app.register_blueprint(blueprint=blue)
    return app
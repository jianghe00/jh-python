from App.ext import db

import random

from flask import Blueprint,render_template

blue = Blueprint('blue',__name__)


@blue.route('/')
def index():
    return 'hello'

@blue.route('/createtable/')
def createtable():
    db.create_all()

    return '创建表单成功'
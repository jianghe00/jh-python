from flask_restful import Resource, reqparse, marshal_with, fields


from werkzeug.security import check_password_hash, generate_password_hash

from App.ext import db
from App.models import User,Movies

parser = reqparse.RequestParser()
parser.add_argument('name', type=str, required=True, help='缺少用户名')

parser.add_argument('tocken', type=str)
parser.add_argument('password', type=str, required=True, help='缺少密码')

parser.add_argument('movieid', type=str, required=True, help='输入要收藏或取消收藏的电影的id')
parser.add_argument('flag', type=str, required=True, help='选择收藏还是取消收藏,flag=1,收藏,flag=2,取消收藏')
movie_fields={
    'id': fields.Integer,
    'showname': fields.String,
    'shownameen': fields.String,
    'director': fields.String,
    'leadingRole': fields.String,
    'type': fields.String,
    'country': fields.String,
    'language': fields.String,
    'duration': fields.Integer,
    'screeningmodel': fields.String,
    'openday': fields.String,
    'backgroundpicture': fields.String,
    'flag': fields.Integer,
}
result_fields={
    'status': fields.Integer,
    'msg': fields.String,
    'data': fields.List(fields.Nested(movie_fields)),
    'error': fields.String(default='')
}

class Collect(Resource):
    @marshal_with(result_fields)
    def post(self):
        parse = parser.parse_args()
        name = parse.get('name')
        password = parse.get('password')
        moiveid=parse.get('movieid')
        flag=parse.get('flag')

        returndata = {}

        users = User.query.filter(User.name == name)
        if users.count()>0: # 存在
            user = users.first()
            if check_password_hash(user.password, password):
                moive = Movie.query.get(moiveid)or 0
                if moive:
                    if flag==1:

                        moive.isdelete=False
                        db.session.add(moive)
                        db.session.commit()

                        returndata['status'] = 200
                        returndata['msg'] = '收藏成功.'
                        return returndata
                    elif flag == 2:
                        moive = Movie.query.filter(Movies.id == moiveid)
                        moive.isdelete = True
                        db.session.add(moive)
                        db.session.commit()

                        returndata['status'] = 200
                        returndata['msg'] = '取消收藏成功.'
                        return returndata
                else:
                    returndata['status'] = 401
                    returndata['error'] = '输入的电影id错误'
                    return returndata


            else:   # 密码错误
                returndata['status'] = 401
                returndata['error'] = '密码错误!'
                return returndata

        else:   # 不存在
            returndata['status'] = 401
            returndata['msg'] = '用户名不存在'
            returndata['error'] = 'token错误!'
            return returndata
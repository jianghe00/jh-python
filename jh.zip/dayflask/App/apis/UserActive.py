from flask_restful import reqparse, fields, Resource, marshal_with

from App.ext import cache, db
from App.models import User

parser = reqparse.RequestParser()
parser.add_argument('token',type=str,required=True,help='请输入token!')

user_field = {
    'name':fields.String,
    'token':fields.String,
    'icon':fields.String,
    'permissions':fields.Integer
}

result_field = {
    'status':fields.Integer,
    'msg':fields.String,
    'data':fields.Nested(user_field),
    'error':fields.String(default=''),
}


class UserActive(Resource):
    @marshal_with(result_field)
    def get(self):
        parse = parser.parse_args()
        token = parse.get('token')

        userid = cache.get(token)

        returndata = {}

        if userid:
            cache.delete(token)
            user = User.query.get(userid)
            user.isactive=True
            db.session.add(user)
            db.session.commit()

            returndata['status'] = 200
            returndata['msg'] = '用户激活成功'
            returndata['data'] = user

            return returndata
        else:
            returndata['status'] = 200
            returndata['msg'] = '激活过期,请联系管理员! xxx-xxx'
            returndata['error'] = '激活失败,超时'
            return returndata

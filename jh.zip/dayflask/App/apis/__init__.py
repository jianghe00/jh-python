from flask_restful import Api

from App.apis.MoviesApi import MoviesResource
from App.apis.PasswordApi import PasswordChange
from App.apis.RegisterApi import Resister
from App.apis.UserActive import UserActive
from App.apis.loginApi import LoginApi
from App.apis.wheels import Wheels
from App.apis.collect import Collect

api = Api()
def init_api(app):
    api.init_app(app)



api.add_resource(Wheels,'/api/v1/wheel/',endpoint='wheel')
api.add_resource(Resister,'/api/v1/resister/',endpoint='resister')
api.add_resource(UserActive,'/api/v1/useractive/',endpoint='useractive')
api.add_resource(LoginApi,'/api/v1/loginapi/',endpoint='loginapi')
api.add_resource(PasswordChange,'/api/v1/passwordchange/',endpoint='passwordchange')
api.add_resource(MoviesResource,'/api/v1/movies/',endpoint='movies')
api.add_resource(Collect,'/api/v1/collect/',endpoint='collect')


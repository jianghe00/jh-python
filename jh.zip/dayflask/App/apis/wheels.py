import time

from flask_restful import Resource, fields, marshal_with

from App.models import Wheel

data = {
    'name':fields.String,
    'img':fields.String,
    'trackid':fields.String
}

datas = {
    'status':fields.Integer,
    'msg':fields.String,
    'time':fields.String,
    'data':fields.List(fields.Nested(data))
}

class Wheels(Resource):
    @marshal_with(datas)
    def get(self):
        wheels = Wheel.query.all()

        returndata = {
            'status': 200,
            'msg': '获取数据成功',
            'time': str(time.time()),
            'data': wheels

        }
        return  returndata
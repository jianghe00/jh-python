import uuid

from flask import render_template
from flask_mail import Message
from flask_restful import reqparse, fields, Resource, marshal_with
from werkzeug.security import check_password_hash

from App.ext import mail, cache, db
from App.models import User

parser = reqparse.RequestParser()
parser.add_argument('username',type=str,required=True,help='输入用户名')
parser.add_argument('password',type=str,required=True,help='输入密码')

user_field = {
    'name':fields.String,
    'token':fields.String,
    'icon':fields.String,
    'permissions':fields.Integer,
}

result_field = {
    'status':fields.Integer,
    'msg':fields.String,
    'data':fields.Nested(user_field),
    'error':fields.String(default='')
}

class LoginApi(Resource):
    @marshal_with(result_field)
    def post(self):
        parse = parser.parse_args()
        name = parse.get('username')
        password = parse.get('password')
        print(name,password)

        users = User.query.filter(User.name == name)
        returndata = {}
        if users.count()>0:
            user = users.first()
            if check_password_hash(user.password,password):
                if user.isdelete==True:
                    returndata['status']=401
                    returndata['msg'] = '登录失败'
                    returndata['error'] = '用户已经被注销'
                    return returndata

                if user.isactive==False:
                    returndata['status'] = 401
                    returndata['msg'] = '登录失败'
                    returndata['error'] = '登录失败'
                    cache.set(user.token, user.id, timeout=100)
                    return returndata
            else:
                returndata['status'] = 401
                returndata['msg'] = '登录失败'
                returndata['error'] = '密码错误'
                return returndata


            user.token = str(uuid.uuid4())
            db.session.add(user)
            db.session.commit()
            returndata['status'] = 200
            returndata['msg'] = '登录成功'
            returndata['data'] = user
            return returndata

        else:   # 账号或密码错误
            returndata['status'] = 401
            returndata['msg'] = '登录失败'
            returndata['error'] = '用户账号错误,请重新登录!'
            return returndata









